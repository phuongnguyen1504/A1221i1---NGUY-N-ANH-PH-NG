package ss10_dsa.service;

import ss10_dsa.model.Student;

public interface IStudentService {
    void addStudent(Student student);
}
