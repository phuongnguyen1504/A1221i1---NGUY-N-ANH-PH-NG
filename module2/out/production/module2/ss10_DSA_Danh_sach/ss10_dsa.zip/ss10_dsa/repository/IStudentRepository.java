package ss10_dsa.repository;

import ss10_dsa.model.Student;

public interface IStudentRepository {
    void saveStudent(Student student);
}
