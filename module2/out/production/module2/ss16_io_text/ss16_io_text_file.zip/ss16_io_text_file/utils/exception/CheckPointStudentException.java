package ss16_io_text_file.utils.exception;

public class CheckPointStudentException extends Exception {
    public CheckPointStudentException(String s) {
        super(s);
    }
}
