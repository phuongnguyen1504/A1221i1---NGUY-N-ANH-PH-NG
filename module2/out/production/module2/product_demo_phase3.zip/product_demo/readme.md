San pham bao gom: id, ten, gia, nha san xuat.

San pham chia lam 2 loai:
+ chinh hang: thoigianbaohanh
+ xach tay: quoc gia xach tay, trang thai
  
Menu: them moi, xoa, xem, tim kiem, thoat
  
Cac tinh nang:
- them moi(id tu tang): them moi chinh hang hay xach tay, luu vao file csv
- xoa theo id: neu id ko hop ly thi throw exception NotFoundProductException
- hien thi ca chinh hang va xach tay
- tim kiem theo ten

#phase 1: crud + search
s1: model-create 3 entity + toString()
s2: menu: write normal first,(scanner, productservice dung chung ko tao bien du thua),  then split yourchoice, function add property dung chung
s3: id auto increment
#phase 2: file csv
