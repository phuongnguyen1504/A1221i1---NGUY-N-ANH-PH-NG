package util;

public interface ConstantUtil {
    String PRODUCT_PATH = "src/data/product.csv";
}
