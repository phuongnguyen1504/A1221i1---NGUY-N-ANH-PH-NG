package ss11_stack_queue;

import java.util.LinkedList;
import java.util.Queue;

public class DemoQueue {
    public static void main(String[] args) {
        Queue<Integer> integers = new LinkedList<>();
        integers.add(5);
        integers.offer(6);
        integers.offer(2);
        while (!integers.isEmpty()) {
            System.out.println(integers.remove());
        }
    }
}
