package ss11_stack_queue;

import java.util.Stack;

public class DemoStack {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
//        stack.add(1);
//        stack.add(0,-1);
        stack.push(1);
        while (!stack.isEmpty()) {
            System.out.println(stack.pop());
        }
    }
}
