package ss11_stack_queue;

public class DemoGeneric<N> {
    public void search(N n) {
        System.out.println(n);
    }
}
