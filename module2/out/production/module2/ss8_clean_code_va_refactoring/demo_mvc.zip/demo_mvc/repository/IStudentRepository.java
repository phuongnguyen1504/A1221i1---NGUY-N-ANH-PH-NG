package demo_mvc.repository;

import demo_mvc.model.Student;

public interface IStudentRepository {
    void saveStudent(Student student);
}
