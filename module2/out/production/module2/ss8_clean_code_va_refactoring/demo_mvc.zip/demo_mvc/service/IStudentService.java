package demo_mvc.service;

import demo_mvc.model.Student;

public interface IStudentService {
    void addStudent(Student student);
}
