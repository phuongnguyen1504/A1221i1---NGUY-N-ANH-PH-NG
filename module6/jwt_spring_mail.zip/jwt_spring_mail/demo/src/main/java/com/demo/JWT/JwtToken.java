package com.demo.JWT;

public class JwtToken {

}
