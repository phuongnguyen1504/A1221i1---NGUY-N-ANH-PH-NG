package cg.crud_template_basic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudTemplateBasicApplication {

    public static void main(String[] args) {
        SpringApplication.run(CrudTemplateBasicApplication.class, args);
    }

}
