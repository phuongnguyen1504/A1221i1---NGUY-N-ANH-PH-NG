// happy coding 👻

function fibonacci(n:number):number{
    if (n<0){
        return -1;
    }
    else if (n==0||n==1){
        return n;
    }
    else{
            return  fibonacci(n-2)+fibonacci(n-1);
    }
};

let n=5;
let sum=0;
for (let i=1;i<=n;i++){
    sum+=fibonacci(i);
}
console.log(sum);
