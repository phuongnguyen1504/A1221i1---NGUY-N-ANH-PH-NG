// happy coding 👻
function fibonacci(n) {
    if (n < 0) {
        return -1;
    }
    else if (n == 0 || n == 1) {
        return n;
    }
    else {
        return fibonacci(n - 2) + fibonacci(n - 1);
    }
}
;
var n = 5;
var sum = 0;
for (var i = 1; i <= n; i++) {
    sum += fibonacci(i);
}
console.log(sum);
